import unittest
from typing import List
from afile import prnItems, Box
from io import StringIO
import sys


class TestPrnItems(unittest.TestCase):
    """Test cases for the prnItems function."""

    def setUp(self):
        """Capture print output for testing."""
        self.held_output = StringIO()
        sys.stdout = self.held_output

    def tearDown(self):
        """Restore normal stdout."""
        sys.stdout = sys.__stdout__

    def test_prnItems_with_list(self):
        """Test prnItems with a regular list."""
        test_list = [1, 2, 3, 4, 5]
        prnItems(test_list)
        output = self.held_output.getvalue()
        self.assertIn('[5, 4, 3, 2, 1]', output)

    def test_prnItems_with_set(self):
        """Test prnItems with a set."""
        test_set = {1, 2, 3}
        prnItems(test_set)
        output = self.held_output.getvalue()
        self.assertTrue(len(output) > 0)

    def test_prnItems_with_strings(self):
        """Test prnItems with a list of strings."""
        test_strs = ['a', 'b', 'c']
        prnItems(test_strs)
        output = self.held_output.getvalue()
        self.assertIn("['c', 'b', 'a']", output)

    def test_prnItems_with_booleans(self):
        """Test prnItems with a list of booleans."""
        test_bools = [True, False, True]
        prnItems(test_bools)
        output = self.held_output.getvalue()
        self.assertIn('[True, False, True]', output)

    def test_prnItems_empty_list(self):
        """Test prnItems with an empty list."""
        prnItems([])
        output = self.held_output.getvalue()
        self.assertIn('[]', output)

    def test_prnItems_single_element(self):
        """Test prnItems with a single element list."""
        prnItems([42])
        output = self.held_output.getvalue()
        self.assertIn('[42]', output)


class TestBox(unittest.TestCase):
    """Test cases for the Box generic container class."""

    def test_box_with_integer(self):
        """Test Box initialization and retrieval with an integer."""
        box = Box(42)
        self.assertEqual(box.get_item(), 42)

    def test_box_with_string(self):
        """Test Box initialization and retrieval with a string."""
        box = Box("Hello World")
        self.assertEqual(box.get_item(), "Hello World")

    def test_box_with_boolean(self):
        """Test Box initialization and retrieval with a boolean."""
        box = Box(True)
        self.assertEqual(box.get_item(), True)

    def test_box_with_list(self):
        """Test Box initialization and retrieval with a list."""
        test_list = [1, 2, 3]
        box = Box(test_list)
        self.assertEqual(box.get_item(), test_list)

    def test_box_with_dict(self):
        """Test Box initialization and retrieval with a dictionary."""
        test_dict = {'key': 'value'}
        box = Box(test_dict)
        self.assertEqual(box.get_item(), test_dict)

    def test_box_with_none(self):
        """Test Box initialization and retrieval with None."""
        box = Box(None)
        self.assertIsNone(box.get_item())

    def test_box_with_float(self):
        """Test Box initialization and retrieval with a float."""
        box = Box(3.14)
        self.assertEqual(box.get_item(), 3.14)

    def test_box_attribute_access(self):
        """Test direct attribute access to box contents."""
        box = Box(99)
        self.assertEqual(box.x, 99)


if __name__ == '__main__':
    unittest.main()
