from typing import List, TypeVar,Generic
T=TypeVar('T')

def prnItems(items:List[T]) -> List[T]:
    """Print items in reverse order.
    
    Args:
        items: A list of items of any type.
        
    Returns:
        The input list unchanged.
    """
    # for item in range(len(items)-1,0,-1):
    #     print(list(items)[item],end=' ')
    # print(items)
    print(list(items)[::-1])

nums={11,12,13,14,15,16,17,18,19,20}
strs=['a','b','c','d','e','f']
bools=[True,False,True,True,True,False]
(prnItems(nums))
print("*"*50)
(prnItems(strs))
print("*"*50)
(prnItems(bools))
print("*"*50)

class Box(Generic[T]):
    """A generic container that holds a single item of any type.
    
    Attributes:
        x: The item stored in the box.
    """
    def __init__(self,x:T):
        """Initialize a Box with an item.
        
        Args:
            x: The item to store in the box.
        """
        self.x=x
    def get_item(self):
        """Retrieve the item from the box.
        
        Returns:
            The item stored in the box.
        """
        return self.x

b=Box(45)
print(b.get_item())
ba=Box("Hai there boxed")
print(ba.get_item())
bb=Box(True)
print(bb.get_item())




