import zope.interface

class MyInterface(zope.interface.Interface):
    x=zope.interface.Attribute('x')
    y=zope.interface.Attribute('y')
    def meth1(self,arg1,arg2):
        pass
    def meth2(self,arg1,arg2):
        pass

class MyInterfacea(zope.interface.Interface):
    x=zope.interface.Attribute('x')
    def meth1a(self,arg1):
        pass

@zope.interface.implementer(MyInterface,MyInterfacea)
class MyClass:
    def meth1(self,arg1,arg2):
        return arg1+arg2
    def meth2(self,arg1,arg2):
        return arg1*arg2
    def meth3(self,arg1,arg2):
        return arg1/arg2

obj = MyClass()
print(obj.meth1(1,2))
print(obj.meth2(1,2))
print(obj.meth3(2,2))
