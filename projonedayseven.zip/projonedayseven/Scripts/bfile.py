from collections import Counter,OrderedDict,defaultdict


def methA():
    """Demonstrate Counter functionality with lists and dictionaries.
    
    Creates and displays Counter objects from lists and keyword arguments,
    showing element counts and dictionary value frequencies.
    """
    ls = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    cca = Counter(ls)
    print(cca)
    for i in cca.keys():
        print(i)
    dicta = {'a': 2122, 'b': 'Revanth Technocrats', 'c': 'LLC'}
    dcount = Counter(dicta.values())
    print(dcount)
    ccb = Counter(A=31, B=43, C=798)
    print(ccb)


def methB():
    """Demonstrate dictionary creation and OrderedDict for key order preservation.
    
    Creates a dictionary mapping numeric values to string keys and demonstrates
    OrderedDict to maintain insertion order.
    """
    ls = [1110, 2, 3, 42222, 5, 6, 7, 8, 9, 10]
    lsa = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']
    dicta = {}
    j = 0
    while j < len(ls):
        dicta[ls[j]] = lsa[j]
        j += 1
    print(dicta)
    # if you want to preserve the order in which the keys were inserted into dict then
    # use OrderedDict
    od = OrderedDict()
    for k, v in dicta.items():
        od[k] = v
    for key, val in od.items():
        print(key, val)


def methC():
    """Demonstrate defaultdict with int and list factory functions.
    
    Shows how defaultdict automatically initializes missing keys with default values,
    using int (default 0) and list (default empty list) as factories.
    """
    d = defaultdict(int)
    L = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    for i in range(len(L)):
        d[i] += 1

    print(d)
    da = defaultdict(list)
    for i in range(1, 11):
        da[i].append(i ** 2)

    print(da)






