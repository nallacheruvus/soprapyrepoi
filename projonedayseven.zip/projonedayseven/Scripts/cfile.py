"""
This module demonstrates the usage of several data structures from the `collections` module:
- `ChainMap`: For combining multiple dictionaries into a single, updateable view.
- `namedtuple`: For creating easy-to-read, self-documenting tuple-like objects with named fields.
- `deque`: A double-ended queue for efficient appends and pops from both ends.
"""

from collections import ChainMap, namedtuple, deque


def methAa():
    """
    Demonstrates the use of `collections.ChainMap` to combine multiple dictionaries.

    A ChainMap groups multiple dictionaries or other mappings together to create a single,
    updateable view. Lookups search the underlying mappings in the order they are given
    until a key is found. Updates, deletions, and insertions only affect the first mapping.
    """
    d1 = {"a": 1, 'b': 2}
    d2 = {"c": 3, 'd': 4}
    d3 = {"e": 5, 'f': 6}
    # Create a ChainMap from the dictionaries d1, d2, and d3.
    # When accessing keys, it will search d1, then d2, then d3.
    c = ChainMap(d1, d2, d3)
    print(c)


def methCc():
    """
    Illustrates the use of `collections.namedtuple` for creating simple classes.

    `namedtuple` creates factory functions for tuple subclasses with named fields.
    This provides an easy way to create lightweight, immutable objects, improving
    code readability and self-documentation compared to plain tuples.
    """
    # Define a namedtuple 'Student' with fields 'name' and 'age'.
    Student = namedtuple('Student', ['name', 'age'])
    # Create an instance of Student.
    s = Student('Agarapolis', 32)
    print(s)
    print(s.name)  # Access fields by name
    print(s.age)
    print(s[0])    # Also accessible by index like a regular tuple
    print(s[1])


def methDd():
    """
    Shows the functionality of `collections.deque` (double-ended queue).

    A deque (double-ended queue) is a list-like container with fast appends and
    pops on either end. It is suitable for implementing queues and stacks.
    """
    # Initialize a deque with some elements.
    queue = deque(['name', 'age', 'dob'])
    print(queue)
    # Remove an element from the left end of the deque.
    queue.popleft()
    print(queue)
    # Remove an element from the right end of the deque.
    queue.pop()
    print(queue)
    # Add an element to the right end of the deque.
    queue.append('SSN')
    # Add an element to the left end of the deque.
    queue.appendleft('SSN-Country')
    print(queue)
