import  array


def methAa():
    arr = array.array('f', (1.0, 1.5, 2.0, 2.5, 3.0, 3.5))
    print(arr)
    print(arr[1])
    print(arr[2])
    print(arr[3])
    print(arr[0])
    print(arr.tolist())
    arr=array.array('f',(1.0,1.5,2.0,2.5,3.0,3.5))
    arr[1]=10.5
    print(arr)

def methDdd():
    class Person:
        def __init__(self, name):
            self.name = name

        def __str__(self):
            return self.name

    aa = ['Sunidhi', 'Jacokbson', 'Motegomery', 'Abel', 'Anastsia']
    li = list()
    j = 1
    for name in aa:
        person = Person(name)
        li.append(person)
    lp = (li)
    for person in lp:
        print(person)





