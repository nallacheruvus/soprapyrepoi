import unittest
from collections import Counter, OrderedDict, defaultdict
from io import StringIO
import sys
from bfile import methA, methB, methC


class TestMethA(unittest.TestCase):
    """Test cases for methA function (Counter demonstrations)."""

    def setUp(self):
        """Capture print output for testing."""
        self.held_output = StringIO()
        sys.stdout = self.held_output

    def tearDown(self):
        """Restore normal stdout."""
        sys.stdout = sys.__stdout__

    def test_methA_runs_without_error(self):
        """Test that methA executes without raising an exception."""
        try:
            methA()
        except Exception as e:
            self.fail(f"methA raised {type(e).__name__} unexpectedly!")

    def test_methA_outputs_counter(self):
        """Test that methA produces output."""
        methA()
        output = self.held_output.getvalue()
        self.assertTrue(len(output) > 0)
        self.assertIn('Counter', output)

    def test_counter_with_list(self):
        """Test Counter functionality with a list."""
        ls = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        cca = Counter(ls)
        self.assertEqual(len(cca), 10)
        for key in cca.keys():
            self.assertEqual(cca[key], 1)

    def test_counter_with_dict_values(self):
        """Test Counter with dictionary values."""
        dicta = {'a': 2122, 'b': 'Revanth Technocrats', 'c': 'LLC'}
        dcount = Counter(dicta.values())
        self.assertIn(2122, dcount)
        self.assertIn('Revanth Technocrats', dcount)
        self.assertIn('LLC', dcount)

    def test_counter_with_kwargs(self):
        """Test Counter initialization with keyword arguments."""
        ccb = Counter(A=31, B=43, C=798)
        self.assertEqual(ccb['A'], 31)
        self.assertEqual(ccb['B'], 43)
        self.assertEqual(ccb['C'], 798)


class TestMethB(unittest.TestCase):
    """Test cases for methB function (OrderedDict demonstrations)."""

    def setUp(self):
        """Capture print output for testing."""
        self.held_output = StringIO()
        sys.stdout = self.held_output

    def tearDown(self):
        """Restore normal stdout."""
        sys.stdout = sys.__stdout__

    def test_methB_runs_without_error(self):
        """Test that methB executes without raising an exception."""
        try:
            methB()
        except Exception as e:
            self.fail(f"methB raised {type(e).__name__} unexpectedly!")

    def test_methB_outputs(self):
        """Test that methB produces output."""
        methB()
        output = self.held_output.getvalue()
        self.assertTrue(len(output) > 0)

    def test_dictionary_creation(self):
        """Test dictionary creation logic from methB."""
        ls = [1110, 2, 3, 42222, 5, 6, 7, 8, 9, 10]
        lsa = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']
        dicta = {}
        for i in range(len(ls)):
            dicta[ls[i]] = lsa[i]
        self.assertEqual(len(dicta), 10)
        self.assertEqual(dicta[1110], 'a')
        self.assertEqual(dicta[42222], 'd')

    def test_ordered_dict_preservation(self):
        """Test that OrderedDict preserves insertion order."""
        od = OrderedDict()
        od[1110] = 'a'
        od[2] = 'b'
        od[3] = 'c'
        keys_list = list(od.keys())
        self.assertEqual(keys_list, [1110, 2, 3])

    def test_ordered_dict_from_dict(self):
        """Test OrderedDict creation from regular dictionary."""
        dicta = {1110: 'a', 2: 'b', 3: 'c', 42222: 'd'}
        od = OrderedDict(dicta)
        self.assertEqual(len(od), 4)
        for key, val in od.items():
            self.assertEqual(dicta[key], val)


class TestMethC(unittest.TestCase):
    """Test cases for methC function (defaultdict demonstrations)."""

    def setUp(self):
        """Capture print output for testing."""
        self.held_output = StringIO()
        sys.stdout = self.held_output

    def tearDown(self):
        """Restore normal stdout."""
        sys.stdout = sys.__stdout__

    def test_methC_runs_without_error(self):
        """Test that methC executes without raising an exception."""
        try:
            methC()
        except Exception as e:
            self.fail(f"methC raised {type(e).__name__} unexpectedly!")

    def test_methC_outputs(self):
        """Test that methC produces output."""
        methC()
        output = self.held_output.getvalue()
        self.assertTrue(len(output) > 0)

    def test_defaultdict_with_int_factory(self):
        """Test defaultdict with int factory function."""
        d = defaultdict(int)
        L = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        for i in range(len(L)):
            d[i] += 1
        self.assertEqual(len(d), 10)
        for i in range(10):
            self.assertEqual(d[i], 1)

    def test_defaultdict_with_list_factory(self):
        """Test defaultdict with list factory function."""
        da = defaultdict(list)
        for i in range(1, 11):
            da[i].append(i ** 2)
        self.assertEqual(len(da), 10)
        self.assertEqual(da[1], [1])
        self.assertEqual(da[5], [25])
        self.assertEqual(da[10], [100])

    def test_defaultdict_auto_initialization(self):
        """Test that defaultdict auto-initializes missing keys."""
        d = defaultdict(int)
        self.assertEqual(d['missing_key'], 0)

    def test_defaultdict_list_auto_initialization(self):
        """Test that defaultdict with list auto-initializes to empty list."""
        d = defaultdict(list)
        self.assertEqual(d['missing_key'], [])
        d['new_key'].append(42)
        self.assertEqual(d['new_key'], [42])


if __name__ == '__main__':
    unittest.main()
